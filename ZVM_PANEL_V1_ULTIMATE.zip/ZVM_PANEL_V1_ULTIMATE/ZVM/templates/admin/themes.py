{% extends "admin-base.html" %}

{% block title %}Theme & Font Forge - {{ panel_name }}{% endblock %}
{% block header_title %}Theme & Font Forge{% endblock %}

{% block breadcrumbs %}
<div class="breadcrumb">
    <a href="{{ url_for('dashboard') }}" class="breadcrumb-item">Dashboard</a>
    <span class="breadcrumb-separator"><i class="fas fa-chevron-right"></i></span>
    <a href="{{ url_for('admin_dashboard') }}" class="breadcrumb-item">Admin</a>
    <span class="breadcrumb-separator"><i class="fas fa-chevron-right"></i></span>
    <span class="breadcrumb-item active">Theme & Font Forge</span>
</div>
{% endblock %}

{% block content %}
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap');

:root {
  --nc: #00f5ff;
  --np: #bf00ff;
  --ng: #00ff88;
  --no: #ff6b00;
}

/* ══ SECTION HEADER ══ */
.forge-section-head {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0,245,255,0.1);
}
.forge-section-icon {
  width: 46px; height: 46px;
  border-radius: 13px;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.2rem;
  flex-shrink: 0;
}
.fsi-cyan   { background: rgba(0,245,255,0.1); color: var(--nc); box-shadow: 0 0 16px rgba(0,245,255,0.15); }
.fsi-purple { background: rgba(191,0,255,0.1); color: var(--np); box-shadow: 0 0 16px rgba(191,0,255,0.15); }
.forge-section-title {
  font-family: 'Orbitron', sans-serif;
  font-size: 1rem; font-weight: 700;
  letter-spacing: 0.05em;
  color: #e0f0ff;
}
.forge-section-sub {
  font-size: 0.8rem;
  color: rgba(0,245,255,0.4);
  margin-top: 2px;
}

/* ══ CYBER CARD ══ */
.forge-card {
  background: rgba(3,8,22,0.9);
  border: 1px solid rgba(0,245,255,0.1);
  border-radius: 20px;
  padding: 1.75rem;
  margin-bottom: 2rem;
  backdrop-filter: blur(20px);
  position: relative;
  overflow: hidden;
  transition: border-color 0.3s ease;
}
.forge-card:hover { border-color: rgba(0,245,255,0.2); }
.forge-card::before {
  content: '';
  position: absolute;
  top: 0; left: 10%; width: 80%; height: 1px;
  background: linear-gradient(90deg, transparent, rgba(0,245,255,0.3), transparent);
}

/* ══ FONT FORGE ══ */
.font-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.font-card {
  position: relative;
  background: rgba(0,245,255,0.03);
  border: 1px solid rgba(0,245,255,0.1);
  border-radius: 14px;
  padding: 1.1rem 1rem;
  cursor: pointer;
  transition: all 0.25s cubic-bezier(0.34,1.56,0.64,1);
  text-align: center;
}
.font-card:hover {
  border-color: rgba(0,245,255,0.35);
  transform: translateY(-4px) scale(1.03);
  box-shadow: 0 12px 30px rgba(0,0,0,0.4), 0 0 20px rgba(0,245,255,0.08);
}
.font-card.active {
  border-color: var(--nc);
  background: rgba(0,245,255,0.07);
  box-shadow: 0 0 0 1px rgba(0,245,255,0.3), 0 0 20px rgba(0,245,255,0.15);
}
.font-card.active::after {
  content: '✓';
  position: absolute;
  top: 8px; right: 10px;
  font-size: 0.75rem;
  font-weight: 700;
  color: var(--nc);
  background: rgba(0,245,255,0.12);
  border: 1px solid rgba(0,245,255,0.3);
  border-radius: 50%;
  width: 20px; height: 20px;
  display: flex; align-items: center; justify-content: center;
}
.font-sample {
  font-size: 1.4rem;
  font-weight: 600;
  color: #e0f0ff;
  margin-bottom: 0.5rem;
  line-height: 1.2;
}
.font-name {
  font-family: 'Inter', sans-serif !important;
  font-size: 0.72rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: rgba(0,245,255,0.5);
}
.font-tag {
  display: inline-block;
  margin-top: 0.4rem;
  padding: 2px 8px;
  border-radius: 6px;
  font-size: 0.62rem;
  font-weight: 600;
  font-family: 'Inter', sans-serif !important;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}
.ft-default { background: rgba(0,255,136,0.1); color: #00ff88; border: 1px solid rgba(0,255,136,0.25); }
.ft-futuristic { background: rgba(0,245,255,0.1); color: #00f5ff; border: 1px solid rgba(0,245,255,0.25); }
.ft-modern { background: rgba(191,0,255,0.1); color: #df88ff; border: 1px solid rgba(191,0,255,0.25); }
.ft-mono { background: rgba(255,107,0,0.1); color: #ff9a4d; border: 1px solid rgba(255,107,0,0.25); }

/* Font live preview bar */
.font-preview-bar {
  background: rgba(0,245,255,0.03);
  border: 1px solid rgba(0,245,255,0.08);
  border-radius: 12px;
  padding: 1.25rem 1.5rem;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  justify-content: space-between;
  flex-wrap: wrap;
}
.fpb-label {
  font-family: 'Orbitron', sans-serif;
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  color: rgba(0,245,255,0.4);
  text-transform: uppercase;
  flex-shrink: 0;
}
.fpb-text {
  flex: 1;
  font-size: 1.1rem;
  color: #e0f0ff;
  text-align: center;
  min-width: 0;
  transition: font-family 0.3s ease;
}
.fpb-reset {
  padding: 6px 16px;
  border-radius: 8px;
  border: 1px solid rgba(255,107,0,0.25);
  background: rgba(255,107,0,0.06);
  color: #ff9a4d;
  font-size: 0.75rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
  font-family: 'Orbitron', sans-serif;
  letter-spacing: 0.04em;
}
.fpb-reset:hover { border-color: rgba(255,107,0,0.5); background: rgba(255,107,0,0.12); }

/* ══ THEME CARDS ══ */
.themes-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 1.25rem;
}
.theme-cy {
  background: rgba(0,245,255,0.03);
  border: 1px solid rgba(0,245,255,0.1);
  border-radius: 16px;
  padding: 1.1rem;
  position: relative;
  transition: all 0.25s ease;
  overflow: hidden;
}
.theme-cy:hover {
  border-color: rgba(0,245,255,0.3);
  transform: translateY(-4px);
  box-shadow: 0 16px 40px rgba(0,0,0,0.5), 0 0 20px rgba(0,245,255,0.06);
}
.theme-cy.tc-active {
  border-color: var(--ng);
  box-shadow: 0 0 0 1px rgba(0,255,136,0.3), 0 0 20px rgba(0,255,136,0.1);
}
.theme-cy.tc-active::before {
  content: '';
  position: absolute;
  top: 0; left: 10%; width: 80%; height: 1.5px;
  background: linear-gradient(90deg, transparent, var(--ng), transparent);
}
.theme-active-badge {
  position: absolute; top: 10px; right: 10px;
  padding: 3px 10px;
  border-radius: 8px;
  font-size: 0.65rem; font-weight: 700;
  letter-spacing: 0.08em; text-transform: uppercase;
  background: rgba(0,255,136,0.1);
  border: 1px solid rgba(0,255,136,0.3);
  color: #00ff88;
  font-family: 'Orbitron', sans-serif;
}
.theme-preview-cy {
  height: 80px;
  border-radius: 10px;
  margin-bottom: 0.85rem;
  overflow: hidden;
  position: relative;
  display: flex; align-items: center; justify-content: center;
}
.theme-preview-cy img {
  position: absolute; inset: 0;
  width: 100%; height: 100%;
  object-fit: cover; opacity: 0.55;
}
.color-dots {
  display: flex; gap: 5px;
  position: relative; z-index: 1;
}
.cdot {
  width: 16px; height: 16px;
  border-radius: 50%;
  border: 1.5px solid rgba(255,255,255,0.2);
}
.theme-nm {
  font-weight: 700; font-size: 0.9rem;
  color: #cce8ff; margin-bottom: 3px;
  font-family: 'Orbitron', sans-serif;
  letter-spacing: 0.03em;
}
.theme-desc {
  font-size: 0.75rem;
  color: rgba(0,245,255,0.4);
  margin-bottom: 0.85rem;
  line-height: 1.4;
}
.theme-actions { display: flex; gap: 0.5rem; }
.btn-apply {
  flex: 1;
  padding: 7px 0;
  border-radius: 9px;
  border: 1px solid rgba(0,245,255,0.25);
  background: rgba(0,245,255,0.08);
  color: var(--nc);
  font-size: 0.75rem; font-weight: 700;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: 'Orbitron', sans-serif;
  letter-spacing: 0.04em;
}
.btn-apply:hover { border-color: rgba(0,245,255,0.5); background: rgba(0,245,255,0.15); box-shadow: 0 0 12px rgba(0,245,255,0.15); }
.btn-del {
  width: 34px;
  border-radius: 9px;
  border: 1px solid rgba(255,0,80,0.2);
  background: rgba(255,0,80,0.06);
  color: rgba(255,0,80,0.6);
  font-size: 0.8rem;
  cursor: pointer;
  transition: all 0.2s ease;
  display: flex; align-items: center; justify-content: center;
}
.btn-del:hover { border-color: rgba(255,0,80,0.5); background: rgba(255,0,80,0.12); color: #ff3366; }

/* ══ CREATE FORM ══ */
.forge-form { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap: 1rem; }
.forge-label {
  font-size: 0.72rem; font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.08em;
  color: rgba(0,245,255,0.5);
  margin-bottom: 0.4rem;
  display: block;
  font-family: 'Orbitron', sans-serif;
}
.forge-input {
  width: 100%;
  background: rgba(0,245,255,0.04);
  border: 1px solid rgba(0,245,255,0.15);
  border-radius: 10px;
  padding: 10px 14px;
  color: #e0f0ff;
  font-size: 0.875rem;
  outline: none;
  transition: all 0.25s ease;
  box-sizing: border-box;
  font-family: inherit;
}
.forge-input:focus {
  border-color: rgba(0,245,255,0.4);
  box-shadow: 0 0 0 3px rgba(0,245,255,0.07);
}
.color-wrap {
  display: flex; gap: 8px; align-items: center;
}
.color-wrap input[type=color] {
  width: 38px; height: 38px;
  border-radius: 8px;
  border: 1px solid rgba(0,245,255,0.2);
  background: transparent;
  padding: 2px; cursor: pointer;
  flex-shrink: 0;
}
.btn-forge-submit {
  padding: 11px 28px;
  border-radius: 11px;
  border: none;
  background: linear-gradient(135deg, #00b8f0, #0050cc);
  color: #fff;
  font-weight: 700;
  font-size: 0.85rem;
  cursor: pointer;
  transition: all 0.25s ease;
  box-shadow: 0 4px 18px rgba(0,180,255,0.3);
  display: inline-flex; align-items: center; gap: 0.5rem;
  font-family: 'Orbitron', sans-serif;
  letter-spacing: 0.05em;
  margin-top: 0.5rem;
}
.btn-forge-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(0,180,255,0.5); }

/* Empty state */
.forge-empty {
  text-align: center; padding: 3rem 2rem;
  color: rgba(0,245,255,0.3);
}
.forge-empty i { font-size: 2.5rem; margin-bottom: 1rem; display: block; }
.forge-empty p { font-size: 0.88rem; }
</style>

<!-- ══ FONT FORGE ══ -->
<div class="forge-card">
  <div class="forge-section-head">
    <div class="forge-section-icon fsi-cyan"><i class="fas fa-font"></i></div>
    <div>
      <div class="forge-section-title">FONT FORGE</div>
      <div class="forge-section-sub">Select a typeface — applies globally across every panel page instantly</div>
    </div>
  </div>

  <!-- Live Preview Bar -->
  <div class="font-preview-bar">
    <span class="fpb-label">Live Preview</span>
    <span class="fpb-text" id="fontPreviewText">AVM Panel — Fast, Secure, Powerful Infrastructure.</span>
    <button class="fpb-reset" onclick="resetFont()"><i class="fas fa-undo"></i> Reset</button>
  </div>

  <!-- Font Grid -->
  <div class="font-grid" id="fontGrid">

    <div class="font-card" data-font="Inter" onclick="setFont(this,'Inter')">
      <div class="font-sample" style="font-family:'Inter',sans-serif;">Aa Bb</div>
      <div class="font-name">Inter</div>
      <div class="font-tag ft-default">Default</div>
    </div>

    <div class="font-card" data-font="Poppins" onclick="setFont(this,'Poppins')">
      <div class="font-sample" style="font-family:'Poppins',sans-serif;">Aa Bb</div>
      <div class="font-name">Poppins</div>
      <div class="font-tag ft-modern">Modern</div>
    </div>

    <div class="font-card" data-font="Space Grotesk" onclick="setFont(this,'Space Grotesk')">
      <div class="font-sample" style="font-family:'Space Grotesk',sans-serif;">Aa Bb</div>
      <div class="font-name">Space Grotesk</div>
      <div class="font-tag ft-modern">Modern</div>
    </div>

    <div class="font-card" data-font="Outfit" onclick="setFont(this,'Outfit')">
      <div class="font-sample" style="font-family:'Outfit',sans-serif;">Aa Bb</div>
      <div class="font-name">Outfit</div>
      <div class="font-tag ft-modern">Modern</div>
    </div>

    <div class="font-card" data-font="Nunito" onclick="setFont(this,'Nunito')">
      <div class="font-sample" style="font-family:'Nunito',sans-serif;">Aa Bb</div>
      <div class="font-name">Nunito</div>
      <div class="font-tag ft-modern">Friendly</div>
    </div>

    <div class="font-card" data-font="Orbitron" onclick="setFont(this,'Orbitron')">
      <div class="font-sample" style="font-family:'Orbitron',sans-serif;">Aa Bb</div>
      <div class="font-name">Orbitron</div>
      <div class="font-tag ft-futuristic">Futuristic</div>
    </div>

    <div class="font-card" data-font="Rajdhani" onclick="setFont(this,'Rajdhani')">
      <div class="font-sample" style="font-family:'Rajdhani',sans-serif;">Aa Bb</div>
      <div class="font-name">Rajdhani</div>
      <div class="font-tag ft-futuristic">Futuristic</div>
    </div>

    <div class="font-card" data-font="Exo 2" onclick="setFont(this,'Exo 2')">
      <div class="font-sample" style="font-family:'Exo 2',sans-serif;">Aa Bb</div>
      <div class="font-name">Exo 2</div>
      <div class="font-tag ft-futuristic">Tech</div>
    </div>

    <div class="font-card" data-font="JetBrains Mono" onclick="setFont(this,'JetBrains Mono')">
      <div class="font-sample" style="font-family:'JetBrains Mono',monospace;">Aa Bb</div>
      <div class="font-name">JetBrains Mono</div>
      <div class="font-tag ft-mono">Mono</div>
    </div>

    <div class="font-card" data-font="Share Tech Mono" onclick="setFont(this,'Share Tech Mono')">
      <div class="font-sample" style="font-family:'Share Tech Mono',monospace;">Aa Bb</div>
      <div class="font-name">Share Tech Mono</div>
      <div class="font-tag ft-mono">Terminal</div>
    </div>

  </div>

  <p style="font-size:0.75rem;color:rgba(0,245,255,0.3);margin-top:0.5rem;">
    <i class="fas fa-info-circle"></i>
    Font choice is saved locally per browser via localStorage. Applies to all pages immediately.
  </p>
</div>

<!-- ══ CREATE THEME ══ -->
<div class="forge-card">
  <div class="forge-section-head">
    <div class="forge-section-icon fsi-purple"><i class="fas fa-plus-circle"></i></div>
    <div>
      <div class="forge-section-title">CREATE NEW THEME</div>
      <div class="forge-section-sub">Define colors and optional GIF background for a custom theme</div>
    </div>
  </div>

  <form id="createThemeForm" enctype="multipart/form-data">
    <div class="forge-form">
      <div>
        <label class="forge-label">Theme Name *</label>
        <input type="text" name="name" class="forge-input" placeholder="My Cyber Theme" required>
      </div>
      <div>
        <label class="forge-label">Description</label>
        <input type="text" name="description" class="forge-input" placeholder="Optional description">
      </div>
      <div>
        <label class="forge-label">Background Primary</label>
        <div class="color-wrap">
          <input type="color" name="bg_primary_picker" value="#0a0c10" oninput="document.querySelector('[name=bg_primary]').value=this.value">
          <input type="text" name="bg_primary" class="forge-input" value="#0a0c10" placeholder="#0a0c10">
        </div>
      </div>
      <div>
        <label class="forge-label">Background Secondary</label>
        <div class="color-wrap">
          <input type="color" name="bg_secondary_picker" value="#111316" oninput="document.querySelector('[name=bg_secondary]').value=this.value">
          <input type="text" name="bg_secondary" class="forge-input" value="#111316" placeholder="#111316">
        </div>
      </div>
      <div>
        <label class="forge-label">Accent Primary</label>
        <div class="color-wrap">
          <input type="color" name="accent_primary_picker" value="#00f5ff" oninput="document.querySelector('[name=accent_primary]').value=this.value">
          <input type="text" name="accent_primary" class="forge-input" value="#00f5ff" placeholder="#00f5ff">
        </div>
      </div>
      <div>
        <label class="forge-label">Accent Secondary</label>
        <div class="color-wrap">
          <input type="color" name="accent_secondary_picker" value="#bf00ff" oninput="document.querySelector('[name=accent_secondary]').value=this.value">
          <input type="text" name="accent_secondary" class="forge-input" value="#bf00ff" placeholder="#bf00ff">
        </div>
      </div>
      <div>
        <label class="forge-label">Text Primary</label>
        <div class="color-wrap">
          <input type="color" name="text_primary_picker" value="#e0f0ff" oninput="document.querySelector('[name=text_primary]').value=this.value">
          <input type="text" name="text_primary" class="forge-input" value="#e0f0ff" placeholder="#e0f0ff">
        </div>
      </div>
      <div>
        <label class="forge-label">GIF / Image URL</label>
        <input type="text" name="gif_url" class="forge-input" placeholder="https://example.com/bg.gif">
      </div>
      <div>
        <label class="forge-label">Upload GIF File</label>
        <input type="file" name="gif_file" class="forge-input" accept=".gif" style="padding:7px 10px;">
      </div>
    </div>
    <button type="submit" class="btn-forge-submit">
      <i class="fas fa-save"></i> Create Theme
    </button>
  </form>
</div>

<!-- ══ INSTALLED THEMES ══ -->
<div class="forge-card">
  <div class="forge-section-head">
    <div class="forge-section-icon fsi-cyan"><i class="fas fa-palette"></i></div>
    <div>
      <div class="forge-section-title">INSTALLED THEMES <span style="color:rgba(0,245,255,0.4);font-size:0.85em;">({{ themes|length }})</span></div>
      <div class="forge-section-sub">Select a theme to apply it site-wide for all users</div>
    </div>
  </div>

  {% if themes %}
  <div class="themes-grid">
    {% for theme in themes %}
    <div class="theme-cy {% if theme.is_active %}tc-active{% endif %}">
      {% if theme.is_active %}
      <div class="theme-active-badge"><i class="fas fa-check"></i> Active</div>
      {% endif %}

      <div class="theme-preview-cy" style="background:{{ theme.bg_primary }};">
        {% if theme.gif_file or theme.gif_url %}
        <img src="{{ theme.gif_file or theme.gif_url }}" alt="Theme preview">
        {% endif %}
        <div class="color-dots">
          <span class="cdot" style="background:{{ theme.bg_primary }};"></span>
          <span class="cdot" style="background:{{ theme.accent_primary }};"></span>
          <span class="cdot" style="background:{{ theme.accent_secondary }};"></span>
          <span class="cdot" style="background:{{ theme.text_primary }};"></span>
        </div>
      </div>

      <div class="theme-nm">{{ theme.name }}</div>
      {% if theme.description %}
      <div class="theme-desc">{{ theme.description }}</div>
      {% else %}
      <div style="margin-bottom:0.85rem;"></div>
      {% endif %}

      <div class="theme-actions">
        {% if not theme.is_active %}
        <button class="btn-apply" onclick="applyTheme({{ theme.id }})">
          <i class="fas fa-bolt"></i> Apply
        </button>
        {% else %}
        <button class="btn-apply" style="opacity:0.4;cursor:default;" disabled>
          <i class="fas fa-check"></i> Active
        </button>
        {% endif %}
        {% if theme.id != 1 %}
        <button class="btn-del" onclick="deleteTheme({{ theme.id }}, '{{ theme.name }}')" title="Delete">
          <i class="fas fa-trash-alt"></i>
        </button>
        {% endif %}
      </div>
    </div>
    {% endfor %}
  </div>
  {% else %}
  <div class="forge-empty">
    <i class="fas fa-palette"></i>
    <p>No themes installed yet. Create your first theme above.</p>
  </div>
  {% endif %}
</div>

<script>
/* ══════════════════════════════════
   FONT FORGE
══════════════════════════════════ */
const FONT_KEY = 'avm_font';
const fontPreview = document.getElementById('fontPreviewText');

// Mark active font on load
(function initFontUI(){
  const saved = localStorage.getItem(FONT_KEY) || 'Inter';
  document.querySelectorAll('.font-card').forEach(c => {
    if(c.dataset.font === saved) c.classList.add('active');
  });
  applyFontToPage(saved);
})();

function setFont(card, fontName){
  // Update active state
  document.querySelectorAll('.font-card').forEach(c => c.classList.remove('active'));
  card.classList.add('active');

  // Save & apply
  localStorage.setItem(FONT_KEY, fontName);
  applyFontToPage(fontName);

  // Toast
  showFontToast(fontName);
}

function applyFontToPage(fontName){
  const val = `'${fontName}', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`;
  document.documentElement.style.setProperty('--font-sans', val);
  // Apply to body directly so preview text shows it
  document.body.style.fontFamily = val;
  if(fontPreview) fontPreview.style.fontFamily = val;
}

function resetFont(){
  localStorage.removeItem(FONT_KEY);
  document.querySelectorAll('.font-card').forEach(c => {
    c.classList.remove('active');
    if(c.dataset.font === 'Inter') c.classList.add('active');
  });
  applyFontToPage('Inter');
  showFontToast('Inter (Reset)');
}

function showFontToast(name){
  const existing = document.getElementById('fontToast');
  if(existing) existing.remove();

  const t = document.createElement('div');
  t.id = 'fontToast';
  t.style.cssText = `
    position:fixed;bottom:100px;left:50%;transform:translateX(-50%);
    background:rgba(0,10,30,0.95);
    border:1px solid rgba(0,245,255,0.3);
    border-radius:12px;padding:10px 22px;
    color:#00f5ff;font-size:0.82rem;font-weight:600;
    box-shadow:0 8px 30px rgba(0,0,0,0.5),0 0 20px rgba(0,245,255,0.1);
    z-index:99999;white-space:nowrap;
    animation:ftIn 0.3s cubic-bezier(0.16,1,0.3,1);
    font-family:'Orbitron','Inter',sans-serif;letter-spacing:0.05em;
  `;
  t.innerHTML = `<i class="fas fa-font" style="margin-right:8px;"></i>Font: ${name}`;
  document.body.appendChild(t);

  const style = document.createElement('style');
  style.textContent = `
    @keyframes ftIn { from{opacity:0;transform:translateX(-50%) translateY(10px)} to{opacity:1;transform:translateX(-50%) translateY(0)} }
  `;
  document.head.appendChild(style);

  setTimeout(() => {
    t.style.transition = 'opacity 0.3s ease';
    t.style.opacity = '0';
    setTimeout(() => t.remove(), 300);
  }, 2500);
}

/* ══════════════════════════════════
   THEME ACTIONS
══════════════════════════════════ */
document.getElementById('createThemeForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const btn = this.querySelector('.btn-forge-submit');
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating...';
  const fd = new FormData(this);
  fetch('/admin/themes/create', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
      if(data.success) { location.reload(); }
      else {
        alert('Error: ' + data.error);
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-save"></i> Create Theme';
      }
    })
    .catch(() => {
      alert('Network error. Please try again.');
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-save"></i> Create Theme';
    });
});

function applyTheme(id) {
  const btn = event.currentTarget;
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Applying...';

  fetch(`/admin/themes/${id}/apply`, { method: 'POST' })
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        // Bust ALL localStorage theme caches
        try {
          localStorage.removeItem('avm_theme_cache');
          localStorage.removeItem('avm_theme_cache_ts');
          localStorage.removeItem('avm_theme_ver');
        } catch(e) {}

        // Immediately inject ALL theme variables via style tag
        if (data.theme) {
          const t = data.theme;
          const acc = t.accent_primary || '#3b82f6';
          const acc2 = t.accent_secondary || '#6366f1';
          const bp = t.bg_primary || '#0a0f1e';
          const bs = t.bg_secondary || '#111316';

          // Remove old overrides
          ['avm-theme-override', 'avm-server-theme'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.remove();
          });

          const css = `
            :root, :root[data-theme="dark"], :root[data-theme="light"] {
              ${t.bg_primary ? `--bg-primary:${t.bg_primary}!important;--b-dark:${t.bg_primary}!important;--dark:${t.bg_primary}!important;--dark-bg:${t.bg_primary}!important;` : ''}
              ${t.bg_secondary ? `--bg-secondary:${t.bg_secondary}!important;--b-card:${t.bg_secondary}!important;--b-glass:${t.bg_secondary}!important;--dark-surface:${t.bg_secondary}!important;` : ''}
              ${t.accent_primary ? `--accent-primary:${t.accent_primary}!important;--b-primary:${t.accent_primary}!important;--blue-primary:${t.accent_primary}!important;--input-focus:${t.accent_primary}!important;--b-p-rgb:${hexToRgb(t.accent_primary)}!important;--b-light:color-mix(in srgb,${t.accent_primary} 70%,white)!important;--b-lighter:color-mix(in srgb,${t.accent_primary} 50%,white)!important;--blue-light:color-mix(in srgb,${t.accent_primary} 70%,white)!important;--b-glow:color-mix(in srgb,${t.accent_primary} 20%,transparent)!important;--b-glow-lg:color-mix(in srgb,${t.accent_primary} 35%,transparent)!important;` : ''}
              ${t.accent_secondary ? `--accent-secondary:${t.accent_secondary}!important;--b-primary-2:${t.accent_secondary}!important;--blue-secondary:${t.accent_secondary}!important;--b-p2-rgb:${hexToRgb(t.accent_secondary)}!important;` : ''}
              ${t.text_primary ? `--text-primary:${t.text_primary}!important;--b-text:${t.text_primary}!important;` : ''}
            }
            body {
              ${t.bg_primary ? `background-color:${t.bg_primary}!important;` : ''}
              ${t.text_primary ? `color:${t.text_primary}!important;` : ''}
            }
            body::before {
              background: radial-gradient(ellipse 80% 60% at 10% 20%, color-mix(in srgb,${acc} 8%,transparent) 0%,transparent 60%),
                radial-gradient(ellipse 60% 50% at 90% 80%, color-mix(in srgb,${acc2} 6%,transparent) 0%,transparent 55%),
                ${bp}!important;
            }
          `;
          const gifSrc = t.gif_file || t.gif_url;
          const gifCss = gifSrc
            ? `body{background-image:url('${gifSrc}')!important;background-size:cover!important;background-position:center!important;background-repeat:no-repeat!important;background-attachment:fixed!important;}`
            : `body{background-image:none!important;}`;

          const s = document.createElement('style');
          s.id = 'avm-theme-override';
          s.textContent = css + gifCss;
          document.head.appendChild(s);

          // Update overlay if present
          const overlay = document.getElementById('themeBgOverlay');
          if (overlay) {
            if (gifSrc) { overlay.style.backgroundImage = `url('${gifSrc}')`; overlay.style.opacity = '0.35'; }
            else { overlay.style.backgroundImage = 'none'; overlay.style.opacity = '0'; }
          }

          // Store in cache WITH version so next page load uses it immediately
          const newVer = data.theme_version || String(Date.now());
          try {
            localStorage.setItem('avm_theme_cache', JSON.stringify(t));
            localStorage.setItem('avm_theme_cache_ts', Date.now().toString());
            localStorage.setItem('avm_theme_ver', newVer);
          } catch(e) {}
        }

        btn.innerHTML = '<i class="fas fa-check"></i> Applied!';
        setTimeout(() => location.reload(), 800);
      } else {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-bolt"></i> Apply';
        alert('Error: ' + data.error);
      }
    })
    .catch(err => {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-bolt"></i> Apply';
      alert('Network error: ' + err.message);
    });
}

function hexToRgb(hex) {
  if (!hex) return '0,0,0';
  hex = hex.replace('#', '');
  if (hex.length === 3) hex = hex.split('').map(c => c+c).join('');
  const r = parseInt(hex.substring(0,2), 16);
  const g = parseInt(hex.substring(2,4), 16);
  const b = parseInt(hex.substring(4,6), 16);
  return `${r},${g},${b}`;
}

function deleteTheme(id, name) {
  if(!confirm(`Delete theme "${name}"? This cannot be undone.`)) return;
  fetch(`/admin/themes/${id}/delete`, { method: 'POST' })
    .then(r => r.json())
    .then(data => {
      if(data.success) location.reload();
      else alert('Error: ' + data.error);
    });
}
</script>
{% endblock %}
