{% extends "admin-base.html" %}

{% block title %}Font Manager - {{ panel_name }}{% endblock %}
{% block header_title %}Font Manager{% endblock %}

{% block breadcrumbs %}
<div class="breadcrumb">
    <a href="{{ url_for('dashboard') }}" class="breadcrumb-item">Dashboard</a>
    <span class="breadcrumb-separator"><i class="fas fa-chevron-right"></i></span>
    <a href="{{ url_for('admin_dashboard') }}" class="breadcrumb-item">Admin</a>
    <span class="breadcrumb-separator"><i class="fas fa-chevron-right"></i></span>
    <span class="breadcrumb-item active">Font Manager</span>
</div>
{% endblock %}

{% block content %}
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Poppins:wght@400;600;700&family=Space+Grotesk:wght@400;600;700&family=Outfit:wght@400;600;700&family=Nunito:wght@400;600;700&family=Rajdhani:wght@400;600;700&family=Exo+2:wght@400;600;700&family=JetBrains+Mono:wght@400;600;700&family=Share+Tech+Mono&display=swap');

:root {
  --fc: #00f5ff;
  --fp: #bf00ff;
  --fg: #00ff88;
  --fo: #ff6b00;
}

/* ── PAGE HEADER ── */
.fm-page-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
  padding: 1.5rem 1.75rem;
  background: rgba(0,245,255,0.03);
  border: 1px solid rgba(0,245,255,0.1);
  border-radius: 18px;
  position: relative;
  overflow: hidden;
}
.fm-page-header::before {
  content: '';
  position: absolute;
  top: 0; left: 10%; width: 80%; height: 1px;
  background: linear-gradient(90deg, transparent, rgba(0,245,255,0.4), transparent);
}
.fm-header-icon {
  width: 56px; height: 56px;
  border-radius: 16px;
  background: linear-gradient(135deg, rgba(0,245,255,0.15), rgba(191,0,255,0.1));
  border: 1px solid rgba(0,245,255,0.25);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.5rem;
  color: var(--fc);
  box-shadow: 0 0 20px rgba(0,245,255,0.15);
  flex-shrink: 0;
}
.fm-header-text h1 {
  font-size: 1.4rem;
  font-weight: 800;
  background: linear-gradient(135deg, #e0f0ff 0%, #00f5ff 50%, #bf00ff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 0.25rem;
}
.fm-header-text p {
  font-size: 0.82rem;
  color: rgba(0,245,255,0.45);
}

/* ── CARD ── */
.fm-card {
  background: rgba(3,8,22,0.9);
  border: 1px solid rgba(0,245,255,0.1);
  border-radius: 20px;
  padding: 1.75rem;
  margin-bottom: 1.75rem;
  backdrop-filter: blur(20px);
  position: relative;
  overflow: hidden;
  transition: border-color 0.3s ease;
}
.fm-card:hover { border-color: rgba(0,245,255,0.2); }
.fm-card::before {
  content: '';
  position: absolute;
  top: 0; left: 10%; width: 80%; height: 1px;
  background: linear-gradient(90deg, transparent, rgba(0,245,255,0.25), transparent);
}

.fm-section-head {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid rgba(0,245,255,0.08);
}
.fm-section-icon {
  width: 40px; height: 40px;
  border-radius: 11px;
  display: flex; align-items: center; justify-content: center;
  font-size: 1rem;
  flex-shrink: 0;
}
.fsi-cyan   { background: rgba(0,245,255,0.1); color: var(--fc); box-shadow: 0 0 14px rgba(0,245,255,0.12); }
.fsi-purple { background: rgba(191,0,255,0.1); color: var(--fp); box-shadow: 0 0 14px rgba(191,0,255,0.12); }
.fsi-green  { background: rgba(0,255,136,0.1); color: var(--fg); box-shadow: 0 0 14px rgba(0,255,136,0.12); }
.fm-section-title {
  font-size: 0.95rem;
  font-weight: 700;
  color: #e0f0ff;
  letter-spacing: 0.04em;
}
.fm-section-sub {
  font-size: 0.75rem;
  color: rgba(0,245,255,0.4);
  margin-top: 2px;
}

/* ── LIVE PREVIEW BAR ── */
.preview-bar {
  background: rgba(0,0,0,0.3);
  border: 1px solid rgba(0,245,255,0.1);
  border-radius: 14px;
  padding: 1.25rem 1.5rem;
  margin-bottom: 1.75rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-wrap: wrap;
}
.preview-label {
  font-size: 0.65rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.12em;
  color: rgba(0,245,255,0.4);
  white-space: nowrap;
  flex-shrink: 0;
}
.preview-content {
  flex: 1;
  min-width: 200px;
}
.preview-big {
  font-size: 1.5rem;
  font-weight: 700;
  color: #e0f0ff;
  line-height: 1.2;
  margin-bottom: 4px;
  transition: font-family 0.3s ease;
}
.preview-small {
  font-size: 0.82rem;
  color: rgba(160,168,184,0.7);
  transition: font-family 0.3s ease;
}
.preview-mono {
  font-size: 0.78rem;
  color: rgba(0,245,255,0.5);
  margin-top: 4px;
  transition: font-family 0.3s ease;
}
.preview-actions {
  display: flex;
  gap: 0.5rem;
  flex-shrink: 0;
}
.btn-preview-reset {
  padding: 7px 16px;
  border-radius: 9px;
  border: 1px solid rgba(255,107,0,0.25);
  background: rgba(255,107,0,0.06);
  color: #ff9a4d;
  font-size: 0.75rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
}
.btn-preview-reset:hover { border-color: rgba(255,107,0,0.5); background: rgba(255,107,0,0.12); }

/* ── FONT GRID ── */
.font-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(175px, 1fr));
  gap: 1rem;
}

.font-card {
  position: relative;
  background: rgba(0,245,255,0.02);
  border: 1px solid rgba(0,245,255,0.1);
  border-radius: 14px;
  padding: 1.2rem 1rem 1rem;
  cursor: pointer;
  transition: all 0.25s cubic-bezier(0.34,1.56,0.64,1);
  text-align: center;
  user-select: none;
}
.font-card:hover {
  border-color: rgba(0,245,255,0.35);
  transform: translateY(-5px) scale(1.02);
  box-shadow: 0 14px 35px rgba(0,0,0,0.45), 0 0 20px rgba(0,245,255,0.08);
  background: rgba(0,245,255,0.04);
}
.font-card.active {
  border-color: var(--fc);
  background: rgba(0,245,255,0.07);
  box-shadow: 0 0 0 1px rgba(0,245,255,0.3), 0 0 25px rgba(0,245,255,0.12);
}
.font-card.active .fc-check {
  opacity: 1;
  transform: scale(1);
}

.fc-check {
  position: absolute;
  top: 8px; right: 8px;
  width: 22px; height: 22px;
  border-radius: 50%;
  background: rgba(0,245,255,0.15);
  border: 1px solid rgba(0,245,255,0.4);
  display: flex; align-items: center; justify-content: center;
  font-size: 0.65rem;
  color: var(--fc);
  opacity: 0;
  transform: scale(0.6);
  transition: all 0.25s cubic-bezier(0.34,1.56,0.64,1);
}

.fc-sample {
  font-size: 1.6rem;
  font-weight: 600;
  color: #e0f0ff;
  margin-bottom: 0.5rem;
  line-height: 1.2;
  min-height: 2rem;
}
.fc-name {
  font-family: 'Inter', sans-serif !important;
  font-size: 0.7rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: rgba(0,245,255,0.5);
  margin-bottom: 0.4rem;
}
.fc-tag {
  display: inline-block;
  padding: 2px 9px;
  border-radius: 6px;
  font-size: 0.6rem;
  font-weight: 700;
  font-family: 'Inter', sans-serif !important;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}
.ft-default    { background: rgba(0,255,136,0.1);  color: #00ff88; border: 1px solid rgba(0,255,136,0.25); }
.ft-modern     { background: rgba(191,0,255,0.1);  color: #df88ff; border: 1px solid rgba(191,0,255,0.25); }
.ft-futuristic { background: rgba(0,245,255,0.1);  color: #00f5ff; border: 1px solid rgba(0,245,255,0.25); }
.ft-mono       { background: rgba(255,107,0,0.1);  color: #ff9a4d; border: 1px solid rgba(255,107,0,0.25); }
.ft-friendly   { background: rgba(255,200,0,0.1);  color: #ffd700; border: 1px solid rgba(255,200,0,0.25); }

/* ── CURRENT FONT DISPLAY ── */
.current-font-display {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem 1.25rem;
  background: rgba(0,255,136,0.04);
  border: 1px solid rgba(0,255,136,0.15);
  border-radius: 12px;
  margin-top: 1.25rem;
}
.cfd-dot {
  width: 10px; height: 10px;
  border-radius: 50%;
  background: #00ff88;
  box-shadow: 0 0 8px rgba(0,255,136,0.6);
  flex-shrink: 0;
  animation: cfdPulse 2s ease-in-out infinite;
}
@keyframes cfdPulse {
  0%,100%{transform:scale(1);opacity:1;}
  50%{transform:scale(1.4);opacity:0.7;}
}
.cfd-text {
  font-size: 0.8rem;
  color: rgba(0,255,136,0.7);
}
.cfd-name {
  font-weight: 700;
  color: #00ff88;
}

/* ── FONT SIZE CONTROL ── */
.size-control {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-wrap: wrap;
}
.size-label {
  font-size: 0.72rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: rgba(0,245,255,0.5);
  white-space: nowrap;
}
.size-slider {
  flex: 1;
  min-width: 150px;
  -webkit-appearance: none;
  height: 4px;
  border-radius: 2px;
  background: rgba(0,245,255,0.15);
  outline: none;
  cursor: pointer;
}
.size-slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 18px; height: 18px;
  border-radius: 50%;
  background: linear-gradient(135deg, #00f5ff, #bf00ff);
  cursor: pointer;
  box-shadow: 0 0 8px rgba(0,245,255,0.5);
  transition: transform 0.2s ease;
}
.size-slider::-webkit-slider-thumb:hover { transform: scale(1.2); }
.size-value {
  font-size: 0.85rem;
  font-weight: 700;
  color: var(--fc);
  min-width: 40px;
  text-align: center;
}
.btn-size-reset {
  padding: 6px 14px;
  border-radius: 8px;
  border: 1px solid rgba(0,245,255,0.2);
  background: rgba(0,245,255,0.05);
  color: rgba(0,245,255,0.6);
  font-size: 0.72rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
}
.btn-size-reset:hover { border-color: rgba(0,245,255,0.4); background: rgba(0,245,255,0.1); color: var(--fc); }

/* ── INFO NOTE ── */
.fm-note {
  display: flex;
  align-items: flex-start;
  gap: 0.6rem;
  padding: 0.85rem 1rem;
  background: rgba(0,245,255,0.03);
  border: 1px solid rgba(0,245,255,0.08);
  border-radius: 10px;
  font-size: 0.75rem;
  color: rgba(0,245,255,0.4);
  margin-top: 1rem;
}
.fm-note i { flex-shrink: 0; margin-top: 1px; }
</style>

<!-- Page Header -->
<div class="fm-page-header">
  <div class="fm-header-icon"><i class="fas fa-font"></i></div>
  <div class="fm-header-text">
    <h1>Font Manager</h1>
    <p>Choose a typeface that applies globally across every panel page — saved per browser</p>
  </div>
</div>

<!-- Live Preview -->
<div class="fm-card">
  <div class="fm-section-head">
    <div class="fm-section-icon fsi-cyan"><i class="fas fa-eye"></i></div>
    <div>
      <div class="fm-section-title">Live Preview</div>
      <div class="fm-section-sub">See how your selected font looks before committing</div>
    </div>
  </div>

  <div class="preview-bar">
    <span class="preview-label">Preview</span>
    <div class="preview-content">
      <div class="preview-big" id="previewBig">AVM Panel — Fast, Secure Infrastructure</div>
      <div class="preview-small" id="previewSmall">Manage your VPS instances with ease. Deploy, monitor, and scale in seconds.</div>
      <div class="preview-mono" id="previewMono">$ ssh root@192.168.1.1 — Connected to node-01</div>
    </div>
    <div class="preview-actions">
      <button class="btn-preview-reset" onclick="resetFont()"><i class="fas fa-undo"></i> Reset</button>
    </div>
  </div>

  <!-- Current font indicator -->
  <div class="current-font-display">
    <div class="cfd-dot"></div>
    <div class="cfd-text">Active font: <span class="cfd-name" id="currentFontName">Inter</span></div>
  </div>
</div>

<!-- Font Size -->
<div class="fm-card">
  <div class="fm-section-head">
    <div class="fm-section-icon fsi-purple"><i class="fas fa-text-height"></i></div>
    <div>
      <div class="fm-section-title">Font Size</div>
      <div class="fm-section-sub">Adjust the base font size for the entire panel</div>
    </div>
  </div>

  <div class="size-control">
    <span class="size-label">Base Size</span>
    <input type="range" class="size-slider" id="sizeSlider" min="12" max="20" value="14" oninput="setFontSize(this.value)">
    <span class="size-value" id="sizeValue">14px</span>
    <button class="btn-size-reset" onclick="resetFontSize()"><i class="fas fa-undo"></i> Reset</button>
  </div>

  <div class="fm-note">
    <i class="fas fa-info-circle"></i>
    Font size is saved locally per browser. Default is 14px. Changes apply immediately to all panel pages.
  </div>
</div>

<!-- Font Picker -->
<div class="fm-card">
  <div class="fm-section-head">
    <div class="fm-section-icon fsi-green"><i class="fas fa-th-large"></i></div>
    <div>
      <div class="fm-section-title">Choose Typeface</div>
      <div class="fm-section-sub">Click any font to apply it instantly across the panel</div>
    </div>
  </div>

  <div class="font-grid" id="fontGrid">

    <div class="font-card" data-font="Inter" onclick="setFont(this,'Inter')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'Inter',sans-serif;">Aa Bb 12</div>
      <div class="fc-name">Inter</div>
      <div class="fc-tag ft-default">Default</div>
    </div>

    <div class="font-card" data-font="Poppins" onclick="setFont(this,'Poppins')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'Poppins',sans-serif;">Aa Bb 12</div>
      <div class="fc-name">Poppins</div>
      <div class="fc-tag ft-modern">Modern</div>
    </div>

    <div class="font-card" data-font="Space Grotesk" onclick="setFont(this,'Space Grotesk')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'Space Grotesk',sans-serif;">Aa Bb 12</div>
      <div class="fc-name">Space Grotesk</div>
      <div class="fc-tag ft-modern">Modern</div>
    </div>

    <div class="font-card" data-font="Outfit" onclick="setFont(this,'Outfit')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'Outfit',sans-serif;">Aa Bb 12</div>
      <div class="fc-name">Outfit</div>
      <div class="fc-tag ft-modern">Modern</div>
    </div>

    <div class="font-card" data-font="Nunito" onclick="setFont(this,'Nunito')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'Nunito',sans-serif;">Aa Bb 12</div>
      <div class="fc-name">Nunito</div>
      <div class="fc-tag ft-friendly">Friendly</div>
    </div>

    <div class="font-card" data-font="Orbitron" onclick="setFont(this,'Orbitron')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'Orbitron',sans-serif;">Aa Bb</div>
      <div class="fc-name">Orbitron</div>
      <div class="fc-tag ft-futuristic">Futuristic</div>
    </div>

    <div class="font-card" data-font="Rajdhani" onclick="setFont(this,'Rajdhani')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'Rajdhani',sans-serif;">Aa Bb 12</div>
      <div class="fc-name">Rajdhani</div>
      <div class="fc-tag ft-futuristic">Futuristic</div>
    </div>

    <div class="font-card" data-font="Exo 2" onclick="setFont(this,'Exo 2')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'Exo 2',sans-serif;">Aa Bb 12</div>
      <div class="fc-name">Exo 2</div>
      <div class="fc-tag ft-futuristic">Tech</div>
    </div>

    <div class="font-card" data-font="JetBrains Mono" onclick="setFont(this,'JetBrains Mono')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'JetBrains Mono',monospace;">Aa Bb</div>
      <div class="fc-name">JetBrains Mono</div>
      <div class="fc-tag ft-mono">Mono</div>
    </div>

    <div class="font-card" data-font="Share Tech Mono" onclick="setFont(this,'Share Tech Mono')">
      <div class="fc-check"><i class="fas fa-check"></i></div>
      <div class="fc-sample" style="font-family:'Share Tech Mono',monospace;">Aa Bb</div>
      <div class="fc-name">Share Tech Mono</div>
      <div class="fc-tag ft-mono">Terminal</div>
    </div>

  </div>

  <div class="fm-note" style="margin-top:1.25rem;">
    <i class="fas fa-info-circle"></i>
    Font selection is stored in your browser's localStorage and applies to all panel pages immediately. Each user can have their own font preference.
  </div>
</div>

<script>
const FONT_KEY  = 'avm_font';
const SIZE_KEY  = 'avm_font_size';

const previewBig   = document.getElementById('previewBig');
const previewSmall = document.getElementById('previewSmall');
const previewMono  = document.getElementById('previewMono');
const currentFontName = document.getElementById('currentFontName');
const sizeSlider   = document.getElementById('sizeSlider');
const sizeValue    = document.getElementById('sizeValue');

/* ── INIT ── */
(function init(){
  const savedFont = localStorage.getItem(FONT_KEY) || 'Inter';
  const savedSize = parseInt(localStorage.getItem(SIZE_KEY)) || 14;

  // Mark active card
  document.querySelectorAll('.font-card').forEach(c => {
    if(c.dataset.font === savedFont) c.classList.add('active');
  });

  applyFont(savedFont);
  applySize(savedSize);
  sizeSlider.value = savedSize;
  sizeValue.textContent = savedSize + 'px';
})();

/* ── FONT ── */
function setFont(card, fontName){
  document.querySelectorAll('.font-card').forEach(c => c.classList.remove('active'));
  card.classList.add('active');
  localStorage.setItem(FONT_KEY, fontName);
  applyFont(fontName);
  showToast('fas fa-font', `Font: ${fontName}`, '#00f5ff');
}

function applyFont(fontName){
  const val = `'${fontName}', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`;
  document.documentElement.style.setProperty('--font-sans', val);
  document.body.style.fontFamily = val;
  if(previewBig)   previewBig.style.fontFamily   = val;
  if(previewSmall) previewSmall.style.fontFamily = val;
  if(previewMono)  previewMono.style.fontFamily  = val;
  if(currentFontName) currentFontName.textContent = fontName;
}

function resetFont(){
  localStorage.removeItem(FONT_KEY);
  document.querySelectorAll('.font-card').forEach(c => {
    c.classList.remove('active');
    if(c.dataset.font === 'Inter') c.classList.add('active');
  });
  applyFont('Inter');
  showToast('fas fa-undo', 'Font reset to Inter', '#ff9a4d');
}

/* ── SIZE ── */
function setFontSize(val){
  const px = parseInt(val);
  sizeValue.textContent = px + 'px';
  applySize(px);
  localStorage.setItem(SIZE_KEY, px);
}

function applySize(px){
  document.documentElement.style.fontSize = px + 'px';
}

function resetFontSize(){
  localStorage.removeItem(SIZE_KEY);
  sizeSlider.value = 14;
  sizeValue.textContent = '14px';
  applySize(14);
  showToast('fas fa-undo', 'Font size reset to 14px', '#ff9a4d');
}

/* ── TOAST ── */
function showToast(icon, msg, color){
  const old = document.getElementById('fmToast');
  if(old) old.remove();

  const t = document.createElement('div');
  t.id = 'fmToast';
  t.style.cssText = `
    position:fixed;bottom:90px;left:50%;transform:translateX(-50%);
    background:rgba(0,5,20,0.96);
    border:1px solid ${color}44;
    border-radius:12px;padding:10px 22px;
    color:${color};font-size:0.82rem;font-weight:600;
    box-shadow:0 8px 30px rgba(0,0,0,0.6),0 0 20px ${color}22;
    z-index:99999;white-space:nowrap;
    animation:fmToastIn 0.3s cubic-bezier(0.16,1,0.3,1);
  `;
  t.innerHTML = `<i class="${icon}" style="margin-right:8px;"></i>${msg}`;
  document.body.appendChild(t);

  if(!document.getElementById('fmToastStyle')){
    const s = document.createElement('style');
    s.id = 'fmToastStyle';
    s.textContent = `@keyframes fmToastIn{from{opacity:0;transform:translateX(-50%) translateY(12px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}`;
    document.head.appendChild(s);
  }

  setTimeout(() => {
    t.style.transition = 'opacity 0.3s ease';
    t.style.opacity = '0';
    setTimeout(() => t.remove(), 300);
  }, 2500);
}
</script>
{% endblock %}
